function openBox(outerid,innerid,url,qs="")
{
	$("#"+outerid).css("visibility","visible");
	$.post(url,qs,
	function(data,status)
	{
		$("#"+innerid).html(data);
	}
	);
}

function closeBox(outerid,innerid)
{
	$("#"+outerid).css("visibility","hidden");
	$("#"+innerid).html("<center><br><br><img src=\"images/loading.gif\"><br><br><h3>Loading...</h3></center>");
}
